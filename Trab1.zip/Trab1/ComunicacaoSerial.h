#ifndef COMUNICACAO_SERIAL_H
#define COMUNICACAO_SERIAL_H

#include <Arduino.h>

class ComunicacaoSerial {
private:
  HardwareSerial &portaTx;     // Referência para a porta de transmissão
  HardwareSerial &portaRx;     // Referência para a porta de recepção
  String bufferRecepcao;       // Buffer para montar a mensagem recebida
  
  // Flag para comunicação entre a ISR e o loop()
  // 'volatile' é essencial para variáveis usadas em interrupções
  volatile bool novaMensagemRecebida; 

public:
  // Construtor que recebe as portas seriais a serem usadas
  ComunicacaoSerial(HardwareSerial &tx, HardwareSerial &rx);
  
  // Inicia a comunicação serial com a taxa de bauds especificada
  void iniciar(long baudRate);
  
  // Envia uma mensagem pela porta de transmissão
  void transmitirMsg(const String &mensagem);
  
  // Lê os dados da porta de recepção (deve ser chamado pela ISR)
  void receberDados();
  
  // Verifica se uma nova mensagem foi recebida (deve ser chamado no loop)
  bool temNovaMensagem();
  
  // Retorna a mensagem recebida e limpa o buffer (deve ser chamado no loop)
  String getMensagemRecebida();
};

#endif