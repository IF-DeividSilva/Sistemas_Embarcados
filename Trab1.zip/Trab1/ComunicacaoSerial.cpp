#include "ComunicacaoSerial.h"

// Implementação do Construtor
ComunicacaoSerial::ComunicacaoSerial(HardwareSerial &tx, HardwareSerial &rx)
  : portaTx(tx), portaRx(rx) { // Inicializa as referências
  bufferRecepcao = "";
  novaMensagemRecebida = false;
}

// Implementação do método para iniciar a comunicação
void ComunicacaoSerial::iniciar(long baudRate) {
  portaTx.begin(baudRate); // Inicia a porta de transmissão
  portaRx.begin(baudRate); // Inicia a porta de recepção
}

// Implementação do método para transmitir mensagens
void ComunicacaoSerial::transmitirMsg(const String &mensagem) {
  portaTx.println(mensagem);
}

// Implementação do método que será chamado pela ISR de recepção
// Esta função deve ser o mais rápida possível.
void ComunicacaoSerial::receberDados() {
  // Apenas lê os dados do buffer da serial e sinaliza quando a mensagem termina.
  while (portaRx.available()) {
    char c = portaRx.read();
    bufferRecepcao += c; // Adiciona o caractere ao buffer
    
    // Se o caractere de fim de linha for recebido, a mensagem está completa.
    if (c == '\n') {
      novaMensagemRecebida = true; // SINALIZA para o loop() que há uma nova mensagem
      break; // Sai do while para manter a ISR curta
    }
  }
}

// Implementação do método que verifica a flag (usado no loop)
bool ComunicacaoSerial::temNovaMensagem() {
  return novaMensagemRecebida;
}

// Implementação do método que obtém a mensagem (usado no loop)
String ComunicacaoSerial::getMensagemRecebida() {
  // Verifica novamente para garantir que a leitura é segura
  if (novaMensagemRecebida) {
    String msgCompleta = bufferRecepcao; // Copia a mensagem para uma variável local
    bufferRecepcao = "";            // Limpa o buffer para a próxima mensagem
    novaMensagemRecebida = false;   // Reseta a flag
    return msgCompleta;
  }
  return ""; // Retorna string vazia se não houver mensagem
}